// This is an automatically generated file, any changes will be overwritten on compiliation!
// DO NOT CHECK THIS INTO SOURCE CONTROL


#ifndef EmbeddedFiles_Defines_H
#define EmbeddedFiles_Defines_H

static const char GIT_VERSION[] = "256670999f7ae2237b8ed7a913f5b9631bb5f405";

static const uint16_t GIT_VERSION_B1 = 0x1bb5;

static const uint16_t GIT_VERSION_B2 = 0xf405;

static const char COMPILE_DATE_TIME[] = "2023-11-13T11:48:01.770Z";

#endif