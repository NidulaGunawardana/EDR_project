This folder gets converted to a LITTLEFS file system for the ESP32 to store files.
The avr folder is used to hold firmware for the inbuilt AVR programmer for modules (ATTINY841)
and shunts (ATMEGA328P)